const Config = {
    API_URL: "https://api.themoviedb.org/3/movie/",
}

export default Config;