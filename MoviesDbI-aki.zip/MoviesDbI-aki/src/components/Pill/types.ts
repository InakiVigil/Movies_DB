export interface IPill {
    title: string;
    color: string;
}