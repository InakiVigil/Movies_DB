export { Home } from './Home';
export { Popular } from './Popular';
export { TopRated } from './Top Rated';
export { Show } from './Show';