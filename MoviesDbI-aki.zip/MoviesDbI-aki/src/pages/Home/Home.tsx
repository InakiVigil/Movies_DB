import { MovieCard } from "../../components/MovieCard";
import { movies } from "../../constants/moviesMock";
import { Popular } from "../Popular";
import { TopRated } from "../Top Rated";

const Home = () => {
  return (
    <div>
      <div className="text-3xl text-black font-bold">Recommended</div>
      <div className="flex flex-row flex-wrap justify-center items-start">
        {movies.map((movie, index) => (
          <MovieCard
            key={movie.id}
            movieId={movie.id}
            posterPath={movie.poster_path}
            title={movie.title}
            voteAverage={movie.vote_average}
            genreId={movie.genre_ids[0]}
          />
        ))}
      </div>
      <div className="text-3xl text-black font-bold">Popular</div>
      <Popular></Popular>
      <div className="text-3xl text-black font-bold">Top Rated</div>
      <TopRated></TopRated>
    </div>
  );
};

export default Home;
