import { Upcoming } from "../pages/Upcoming";

export const ROUTES = {
    HOME: '/',
    POPULAR: '/popular',
    TOPRATED: '/top_rated',
    UPCOMING: '/upcoming',
    SHOW: '/show/',
    FAVORITES: '/favorites'
};